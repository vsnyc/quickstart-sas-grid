quickstart-microsoft-utilities
==============

These utility scripts are common scripts shared by the Microsoft based AWS Quick Starts
